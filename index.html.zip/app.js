// ========== GLOBAL STATE ==========
let allVoices = [];
let selectedVoiceType = 'male';
let isSpeaking = false;
let isPaused = false;
let chatbotOpen = false;
let isProUser = localStorage.getItem('skyrootPro') === 'true';

// ========== INITIALIZATION ==========
document.addEventListener('DOMContentLoaded', () => {
    createParticles();
    loadVoices();
    setupForms();
    setupPasswordStrength();
    drawIdleWave();
    checkProStatus();
});

// ========== PARTICLES ==========
function createParticles() {
    const container = document.getElementById('particles');
    if (!container) return;
    for (let i = 0; i < 50; i++) {
        const p = document.createElement('div');
        p.className = 'particle';
        p.style.left = Math.random() * 100 + '%';
        p.style.animationDelay = Math.random() * 10 + 's';
        p.style.animationDuration = (8 + Math.random() * 12) + 's';
        p.style.width = p.style.height = (2 + Math.random() * 3) + 'px';
        container.appendChild(p);
    }
}

// ========== PAGE NAVIGATION ==========
function showPage(pageId) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    const page = document.getElementById(pageId);
    if (page) {
        page.classList.add('active');
        // Re-animate the auth container
        const container = page.querySelector('.auth-container');
        if (container) {
            container.style.animation = 'none';
            container.offsetHeight; // trigger reflow
            container.style.animation = '';
        }
    }
    // Hide chatbot FAB on auth pages
    const fab = document.getElementById('chatbotFab');
    if (fab) fab.style.display = (pageId === 'appPage') ? 'block' : 'none';
}

// ========== CAPTCHA ==========
function handleCaptcha(checkbox, statusId) {
    const status = document.getElementById(statusId);
    if (checkbox.checked) {
        // Simulate verification
        status.textContent = 'Verifying...';
        status.className = 'captcha-status';
        setTimeout(() => {
            // 70% chance of success, 30% chance of retry
            if (Math.random() > 0.3) {
                status.textContent = '✓ Verified successfully';
                status.className = 'captcha-status success';
                checkFormValidity(checkbox.closest('form'));
            } else {
                status.textContent = '✗ Please try again';
                status.className = 'captcha-status error';
                checkbox.checked = false;
                setTimeout(() => { status.textContent = ''; }, 2000);
            }
        }, 1500);
    } else {
        status.textContent = '';
        checkFormValidity(checkbox.closest('form'));
    }
}

function checkFormValidity(form) {
    if (!form) return;
    const btn = form.querySelector('.btn-primary');
    const captchaChecked = form.querySelector('.captcha-check input:checked');
    const inputs = form.querySelectorAll('input[required]');
    let allFilled = true;
    inputs.forEach(input => { if (!input.value.trim()) allFilled = false; });
    btn.disabled = !(captchaChecked && allFilled);
}

// ========== FORMS ==========
function setupForms() {
    // Login form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('input', () => checkFormValidity(loginForm));
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const btn = loginForm.querySelector('.btn-primary');
            btn.classList.add('loading');
            setTimeout(() => {
                btn.classList.remove('loading');
                const email = document.getElementById('loginEmail').value;
                const name = email.split('@')[0];
                document.getElementById('userName').textContent = name.charAt(0).toUpperCase() + name.slice(1);
                showPage('appPage');
                showToast('Welcome back, ' + name + '! 🎉');
            }, 1500);
        });
    }

    // Signup form
    const signupForm = document.getElementById('signupForm');
    if (signupForm) {
        signupForm.addEventListener('input', () => checkFormValidity(signupForm));
        signupForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const pass = document.getElementById('signupPassword').value;
            const confirm = document.getElementById('signupConfirm').value;
            if (pass !== confirm) {
                showToast('Passwords do not match!', true);
                return;
            }
            const btn = signupForm.querySelector('.btn-primary');
            btn.classList.add('loading');
            setTimeout(() => {
                btn.classList.remove('loading');
                const name = document.getElementById('signupName').value.split(' ')[0];
                document.getElementById('userName').textContent = name;
                showPage('appPage');
                showToast('Account created! Welcome, ' + name + '! 🎉');
            }, 2000);
        });
    }
}

// ========== PASSWORD ==========
function togglePassword(inputId, btn) {
    const input = document.getElementById(inputId);
    const icon = btn.querySelector('i');
    if (input.type === 'password') {
        input.type = 'text';
        icon.className = 'fas fa-eye-slash';
    } else {
        input.type = 'password';
        icon.className = 'fas fa-eye';
    }
}

function setupPasswordStrength() {
    const input = document.getElementById('signupPassword');
    if (!input) return;
    input.addEventListener('input', () => {
        const val = input.value;
        let strength = 0;
        if (val.length >= 6) strength++;
        if (val.length >= 10) strength++;
        if (/[A-Z]/.test(val)) strength++;
        if (/[0-9]/.test(val)) strength++;
        if (/[^A-Za-z0-9]/.test(val)) strength++;

        const fill = document.getElementById('strengthFill');
        const text = document.getElementById('strengthText');
        const levels = [
            { w: '0%', c: 'transparent', t: '' },
            { w: '20%', c: '#ff1744', t: 'Very Weak' },
            { w: '40%', c: '#ff9100', t: 'Weak' },
            { w: '60%', c: '#ffd600', t: 'Fair' },
            { w: '80%', c: '#00c853', t: 'Strong' },
            { w: '100%', c: '#00e676', t: 'Very Strong' }
        ];
        const level = levels[strength];
        fill.style.width = level.w;
        fill.style.background = level.c;
        text.textContent = level.t;
        text.style.color = level.c;
    });
}

// ========== SOCIAL LOGIN ==========
function socialLogin(provider) {
    showToast('Connecting to ' + provider + '...');
    setTimeout(() => {
        document.getElementById('userName').textContent = provider + ' User';
        showPage('appPage');
        showToast('Logged in with ' + provider + '! 🎉');
    }, 1500);
}

// ========== USER MENU ==========
function toggleUserMenu() {
    const dd = document.getElementById('userDropdown');
    dd.classList.toggle('show');
    // Close on outside click
    setTimeout(() => {
        document.addEventListener('click', function closeMenu(e) {
            if (!e.target.closest('.user-menu')) {
                dd.classList.remove('show');
                document.removeEventListener('click', closeMenu);
            }
        });
    }, 10);
}

// ========== VOICES ==========
function loadVoices() {
    const synth = window.speechSynthesis;

    function populateVoices() {
        allVoices = synth.getVoices();
        if (allVoices.length === 0) return;

        const select = document.getElementById('voiceSelect');
        const langSelect = document.getElementById('languageSelect');
        if (!select || !langSelect) return;

        // Populate languages
        const langs = new Set();
        allVoices.forEach(v => langs.add(v.lang));
        langSelect.innerHTML = '<option value="all">All Languages</option>';
        const sortedLangs = [...langs].sort();
        sortedLangs.forEach(lang => {
            const opt = document.createElement('option');
            opt.value = lang;
            opt.textContent = getLanguageName(lang) + ' (' + lang + ')';
            langSelect.appendChild(opt);
        });

        populateVoiceList(allVoices);
    }

    populateVoices();
    if (synth.onvoiceschanged !== undefined) {
        synth.onvoiceschanged = populateVoices;
    }
    // Retry for browsers that load voices async
    setTimeout(populateVoices, 500);
    setTimeout(populateVoices, 1500);
}

function populateVoiceList(voices) {
    const select = document.getElementById('voiceSelect');
    if (!select) return;
    select.innerHTML = '';

    const filtered = filterByVoiceType(voices);
    if (filtered.length === 0) {
        select.innerHTML = '<option>No voices match. Showing all...</option>';
        voices.forEach((v, i) => {
            const opt = document.createElement('option');
            opt.value = i;
            opt.textContent = v.name + ' (' + v.lang + ')';
            select.appendChild(opt);
        });
    } else {
        filtered.forEach((v) => {
            const opt = document.createElement('option');
            opt.value = allVoices.indexOf(v);
            opt.textContent = v.name + ' (' + v.lang + ')';
            select.appendChild(opt);
        });
    }
}

function filterByVoiceType(voices) {
    return voices.filter(v => {
        const name = v.name.toLowerCase();
        switch (selectedVoiceType) {
            case 'female':
                return name.includes('female') || name.includes('woman') || name.includes('zira') ||
                    name.includes('hazel') || name.includes('samantha') || name.includes('victoria') ||
                    name.includes('karen') || name.includes('moira') || name.includes('tessa') ||
                    name.includes('fiona') || name.includes('linda') || name.includes('susan');
            case 'child':
                return name.includes('child') || name.includes('kid') || name.includes('young');
            case 'deep':
            case 'elder':
            case 'narrator':
                return name.includes('male') || name.includes('david') || name.includes('mark') ||
                    name.includes('daniel') || name.includes('james') || name.includes('alex');
            case 'robot':
            case 'alien':
            case 'echo':
                return voices.length > 0; // show all voices for special effects
            case 'whisper':
                return name.includes('female') || name.includes('woman') || name.includes('zira');
            case 'news':
                return name.includes('male') || name.includes('david') || name.includes('daniel');
            case 'male':
            default:
                return name.includes('male') || name.includes('man') || name.includes('david') ||
                    name.includes('mark') || name.includes('daniel') || name.includes('james') ||
                    name.includes('rishi') || name.includes('alex');
        }
    });
}

function filterVoicesByLang() {
    const lang = document.getElementById('languageSelect').value;
    let voices = allVoices;
    if (lang !== 'all') {
        voices = allVoices.filter(v => v.lang === lang);
    }
    populateVoiceList(voices);
}

function selectVoiceType(type, btn) {
    selectedVoiceType = type;
    document.querySelectorAll('.voice-type-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    filterVoicesByLang();

    // Auto-adjust pitch & rate for each voice type
    const pitch = document.getElementById('pitchRange');
    const speed = document.getElementById('speedRange');
    const settings = {
        male:    { p: 1.0, s: 1.0 },
        female:  { p: 1.3, s: 1.0 },
        child:   { p: 1.6, s: 1.05 },
        deep:    { p: 0.6, s: 0.85 },
        robot:   { p: 0.4, s: 0.7 },
        whisper: { p: 1.0, s: 0.6 },
        echo:    { p: 0.9, s: 0.9 },
        news:    { p: 1.0, s: 0.95 },
        narrator:{ p: 0.85, s: 0.85 },
        elder:   { p: 0.7, s: 0.75 },
        alien:   { p: 1.8, s: 1.3 }
    };
    const s = settings[type] || settings.male;
    pitch.value = s.p;
    speed.value = s.s;
    updateSlider('pitch');
    updateSlider('speed');
}

function getLanguageName(code) {
    const names = {
        'en': 'English', 'en-US': 'English (US)', 'en-GB': 'English (UK)', 'en-AU': 'English (AU)',
        'es': 'Spanish', 'es-ES': 'Spanish (Spain)', 'es-MX': 'Spanish (Mexico)',
        'fr': 'French', 'fr-FR': 'French', 'de': 'German', 'de-DE': 'German',
        'it': 'Italian', 'it-IT': 'Italian', 'pt': 'Portuguese', 'pt-BR': 'Portuguese (BR)',
        'ru': 'Russian', 'ru-RU': 'Russian', 'ja': 'Japanese', 'ja-JP': 'Japanese',
        'ko': 'Korean', 'ko-KR': 'Korean', 'zh': 'Chinese', 'zh-CN': 'Chinese (Simplified)',
        'zh-TW': 'Chinese (Traditional)', 'ar': 'Arabic', 'ar-SA': 'Arabic (Saudi)',
        'hi': 'Hindi', 'hi-IN': 'Hindi', 'ur': 'Urdu', 'ur-PK': 'Urdu',
        'tr': 'Turkish', 'tr-TR': 'Turkish', 'nl': 'Dutch', 'nl-NL': 'Dutch',
        'pl': 'Polish', 'pl-PL': 'Polish', 'sv': 'Swedish', 'sv-SE': 'Swedish',
        'da': 'Danish', 'da-DK': 'Danish', 'fi': 'Finnish', 'fi-FI': 'Finnish',
        'no': 'Norwegian', 'nb-NO': 'Norwegian', 'el': 'Greek', 'el-GR': 'Greek',
        'he': 'Hebrew', 'he-IL': 'Hebrew', 'th': 'Thai', 'th-TH': 'Thai',
        'vi': 'Vietnamese', 'vi-VN': 'Vietnamese', 'id': 'Indonesian', 'id-ID': 'Indonesian',
        'cs': 'Czech', 'cs-CZ': 'Czech', 'ro': 'Romanian', 'ro-RO': 'Romanian',
        'hu': 'Hungarian', 'hu-HU': 'Hungarian', 'uk': 'Ukrainian', 'uk-UA': 'Ukrainian',
        'bn': 'Bengali', 'bn-IN': 'Bengali', 'ta': 'Tamil', 'ta-IN': 'Tamil',
        'te': 'Telugu', 'te-IN': 'Telugu', 'ms': 'Malay', 'ms-MY': 'Malay'
    };
    return names[code] || code;
}

// ========== TEXT TO SPEECH ==========
function togglePlay() {
    if (isPaused) {
        window.speechSynthesis.resume();
        isPaused = false;
        updatePlayButton(true);
        return;
    }
    if (isSpeaking) {
        stopSpeech();
        return;
    }
    speakText();
}

function speakText() {
    const text = document.getElementById('textInput').value.trim();
    if (!text) {
        showToast('Please enter some text first!', true);
        return;
    }

    const synth = window.speechSynthesis;
    synth.cancel();

    const utterance = new SpeechSynthesisUtterance(text);

    // Set voice
    const voiceSelect = document.getElementById('voiceSelect');
    const voiceIndex = voiceSelect.value;
    if (allVoices[voiceIndex]) {
        utterance.voice = allVoices[voiceIndex];
    }

    // Set parameters
    utterance.rate = parseFloat(document.getElementById('speedRange').value);
    utterance.pitch = parseFloat(document.getElementById('pitchRange').value);
    utterance.volume = parseFloat(document.getElementById('volumeRange').value);

    utterance.onstart = () => {
        isSpeaking = true;
        isPaused = false;
        updatePlayButton(true);
        updateNowPlaying('Speaking...', true);
        animateWave();
    };

    utterance.onend = () => {
        isSpeaking = false;
        isPaused = false;
        updatePlayButton(false);
        updateNowPlaying('Finished! ✓', false);
        stopWaveAnimation();
    };

    utterance.onerror = (e) => {
        if (e.error !== 'canceled') {
            isSpeaking = false;
            updatePlayButton(false);
            updateNowPlaying('Error occurred', false);
            stopWaveAnimation();
        }
    };

    synth.speak(utterance);
}

function pauseSpeech() {
    const synth = window.speechSynthesis;
    if (isSpeaking && !isPaused) {
        synth.pause();
        isPaused = true;
        updatePlayButton(false);
        updateNowPlaying('Paused', false);
        stopWaveAnimation();
    } else if (isPaused) {
        synth.resume();
        isPaused = false;
        updatePlayButton(true);
        updateNowPlaying('Speaking...', true);
        animateWave();
    }
}

function stopSpeech() {
    window.speechSynthesis.cancel();
    isSpeaking = false;
    isPaused = false;
    updatePlayButton(false);
    updateNowPlaying('Stopped', false);
    stopWaveAnimation();
}

function skipBack() {
    if (isSpeaking || isPaused) {
        stopSpeech();
        setTimeout(() => speakText(), 100);
    }
}

function updatePlayButton(playing) {
    const icon = document.querySelector('#playBtn i');
    icon.className = playing ? 'fas fa-pause' : 'fas fa-play';
}

function updateNowPlaying(text, active) {
    const np = document.getElementById('nowPlaying');
    np.querySelector('.playing-text').textContent = text;
    const bars = np.querySelectorAll('.playing-indicator span');
    bars.forEach(bar => {
        bar.style.animationPlayState = active ? 'running' : 'paused';
    });
}

// ========== WAVE VISUALIZER ==========
let waveAnimId = null;

function animateWave() {
    const canvas = document.getElementById('waveCanvas');
    const ctx = canvas.getContext('2d');
    canvas.width = canvas.offsetWidth * 2;
    canvas.height = canvas.offsetHeight * 2;

    let time = 0;
    function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        const w = canvas.width, h = canvas.height;

        // Draw multiple wave layers
        for (let layer = 0; layer < 3; layer++) {
            ctx.beginPath();
            const gradient = ctx.createLinearGradient(0, 0, w, 0);
            if (layer === 0) {
                gradient.addColorStop(0, 'rgba(108, 99, 255, 0.6)');
                gradient.addColorStop(1, 'rgba(255, 101, 132, 0.6)');
            } else if (layer === 1) {
                gradient.addColorStop(0, 'rgba(0, 210, 255, 0.4)');
                gradient.addColorStop(1, 'rgba(123, 47, 247, 0.4)');
            } else {
                gradient.addColorStop(0, 'rgba(248, 87, 166, 0.3)');
                gradient.addColorStop(1, 'rgba(255, 88, 88, 0.3)');
            }
            ctx.strokeStyle = gradient;
            ctx.lineWidth = 2 + layer;

            for (let x = 0; x < w; x++) {
                const freq = 0.005 + layer * 0.003;
                const amp = (h / 4) * (1 - layer * 0.2);
                const y = h / 2 + Math.sin(x * freq + time + layer * 2) * amp *
                    Math.sin(x * 0.001 + time * 0.5);
                if (x === 0) ctx.moveTo(x, y);
                else ctx.lineTo(x, y);
            }
            ctx.stroke();
        }
        time += 0.04;
        waveAnimId = requestAnimationFrame(draw);
    }
    draw();
}

function stopWaveAnimation() {
    if (waveAnimId) {
        cancelAnimationFrame(waveAnimId);
        waveAnimId = null;
    }
    drawIdleWave();
}

function drawIdleWave() {
    const canvas = document.getElementById('waveCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    canvas.width = canvas.offsetWidth * 2;
    canvas.height = canvas.offsetHeight * 2;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const w = canvas.width, h = canvas.height;
    ctx.beginPath();
    ctx.strokeStyle = 'rgba(108, 99, 255, 0.2)';
    ctx.lineWidth = 2;
    for (let x = 0; x < w; x++) {
        const y = h / 2 + Math.sin(x * 0.01) * 5;
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
    }
    ctx.stroke();
}

// ========== SLIDERS ==========
function updateSlider(type) {
    switch (type) {
        case 'speed':
            document.getElementById('speedValue').textContent =
                parseFloat(document.getElementById('speedRange').value).toFixed(1) + 'x';
            break;
        case 'pitch':
            document.getElementById('pitchValue').textContent =
                parseFloat(document.getElementById('pitchRange').value).toFixed(1);
            break;
        case 'volume':
            document.getElementById('volumeValue').textContent =
                Math.round(document.getElementById('volumeRange').value * 100) + '%';
            break;
    }
}

// ========== QUICK ACTIONS ==========
function updateCharCount() {
    const count = document.getElementById('textInput').value.length;
    document.getElementById('charCount').textContent = count;
}

async function pasteText() {
    try {
        const text = await navigator.clipboard.readText();
        document.getElementById('textInput').value = text;
        updateCharCount();
        showToast('Text pasted!');
    } catch (e) {
        showToast('Unable to paste. Please use Ctrl+V', true);
    }
}

function clearText() {
    document.getElementById('textInput').value = '';
    updateCharCount();
    showToast('Text cleared!');
}

function sampleText() {
    const samples = [
        "Hello! Welcome to Text to Voice, the most amazing text-to-speech application. I can speak in many languages and with different voices. Try me out!",
        "The quick brown fox jumps over the lazy dog. This sentence contains every letter of the English alphabet. Isn't that fascinating?",
        "In a world full of technology, voice is the most natural way to communicate. Let your words come alive with Text to Voice!",
        "Did you know that the human ear can distinguish between 400,000 different sounds? Our voices are incredibly complex and beautiful instruments.",
        "Welcome to the future of communication! Text to Voice brings your written words to life with natural sounding speech in multiple languages."
    ];
    document.getElementById('textInput').value = samples[Math.floor(Math.random() * samples.length)];
    updateCharCount();
    showToast('Sample text loaded!');
}

// ========== MP3 DOWNLOAD ==========
function downloadAudio() {
    const text = document.getElementById('textInput').value.trim();
    if (!text) { showToast('Enter text first!', true); return; }

    showToast('Recording audio for download...');

    const synth = window.speechSynthesis;
    synth.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    const voiceSelect = document.getElementById('voiceSelect');
    if (allVoices[voiceSelect.value]) utterance.voice = allVoices[voiceSelect.value];
    utterance.rate = parseFloat(document.getElementById('speedRange').value);
    utterance.pitch = parseFloat(document.getElementById('pitchRange').value);
    utterance.volume = parseFloat(document.getElementById('volumeRange').value);

    // Try using MediaRecorder with system audio
    try {
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const dest = audioCtx.createMediaStreamDestination();
        const mediaRecorder = new MediaRecorder(dest.stream, { mimeType: 'audio/webm' });
        const chunks = [];

        mediaRecorder.ondataavailable = e => { if (e.data.size > 0) chunks.push(e.data); };
        mediaRecorder.onstop = () => {
            const blob = new Blob(chunks, { type: 'audio/webm' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'text-to-voice-' + Date.now() + '.webm';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            showToast('Audio downloaded successfully! 🎵');
            audioCtx.close();
        };

        mediaRecorder.start();
        utterance.onend = () => {
            setTimeout(() => { mediaRecorder.stop(); }, 500);
        };
        synth.speak(utterance);
    } catch (e) {
        // Fallback: speak and use WAV generation via OfflineAudioContext
        synth.speak(utterance);
        // Generate a WAV file using oscillator as fallback
        generateAndDownloadWAV(text);
    }
}

function generateAndDownloadWAV(text) {
    // Use a simple approach: create audio buffer with speech duration estimate
    const rate = parseFloat(document.getElementById('speedRange').value);
    const duration = Math.max(2, (text.length / 10) / rate); // estimate duration
    const sampleRate = 22050;
    const numSamples = Math.floor(duration * sampleRate);
    const buffer = new ArrayBuffer(44 + numSamples * 2);
    const view = new DataView(buffer);

    // WAV header
    function writeString(offset, str) { for (let i = 0; i < str.length; i++) view.setUint8(offset + i, str.charCodeAt(i)); }
    writeString(0, 'RIFF');
    view.setUint32(4, 36 + numSamples * 2, true);
    writeString(8, 'WAVE');
    writeString(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, 1, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    writeString(36, 'data');
    view.setUint32(40, numSamples * 2, true);

    // Generate simple sine wave tones as placeholder audio
    const pitch = parseFloat(document.getElementById('pitchRange').value);
    const baseFreq = 220 * pitch;
    for (let i = 0; i < numSamples; i++) {
        const t = i / sampleRate;
        const envelope = Math.min(1, t * 10) * Math.max(0, 1 - (t - duration + 0.5) * 10);
        const val = Math.sin(2 * Math.PI * baseFreq * t) * 0.3 * envelope +
                    Math.sin(2 * Math.PI * baseFreq * 1.5 * t) * 0.1 * envelope;
        view.setInt16(44 + i * 2, val * 32767, true);
    }

    const blob = new Blob([buffer], { type: 'audio/wav' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'text-to-voice-' + Date.now() + '.wav';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('WAV audio downloaded! For real speech MP3, use Pro version.');
}

// ========== CHATBOT ==========
function toggleChatbot() {
    const chatbot = document.getElementById('chatbot');
    const fab = document.getElementById('chatbotFab');
    chatbotOpen = !chatbotOpen;
    if (chatbotOpen) {
        chatbot.classList.add('open');
        fab.style.display = 'none';
    } else {
        chatbot.classList.remove('open');
        fab.style.display = 'block';
    }
}

function sendMessage() {
    const input = document.getElementById('chatInput');
    const msg = input.value.trim();
    if (!msg) return;
    addChatMessage(msg, 'user');
    input.value = '';
    // Hide suggestions after first message
    document.getElementById('chatSuggestions').style.display = 'none';
    // Bot typing effect with delay
    setTimeout(() => {
        const response = getAIResponse(msg);
        addChatMessage(response, 'bot');
        // Auto-fill text area with bot response
        setTimeout(() => {
            document.getElementById('textInput').value = response;
            updateCharCount();
        }, 300);
    }, 800 + Math.random() * 700);
}

function sendSuggestion(text) {
    document.getElementById('chatInput').value = text;
    sendMessage();
}

function addChatMessage(text, sender) {
    const body = document.getElementById('chatbotBody');
    const div = document.createElement('div');
    div.className = 'chat-message ' + (sender === 'user' ? 'user-message' : 'bot-message');
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    div.innerHTML = `
        <div class="msg-avatar"><i class="fas fa-${sender === 'user' ? 'user' : 'robot'}"></i></div>
        <div class="msg-bubble">
            <p>${text}</p>
            <span class="msg-time">${time}</span>
        </div>
    `;
    body.appendChild(div);
    body.scrollTop = body.scrollHeight;
}

// ========== PRO VERSION ==========
function showProModal() {
    document.getElementById('proModal').classList.add('show');
}

function closeProModal() {
    document.getElementById('proModal').classList.remove('show');
}

function activatePro(plan) {
    isProUser = true;
    localStorage.setItem('skyrootPro', 'true');
    document.getElementById('proBadge').style.display = 'inline-block';
    closeProModal();
    showToast('🎉 Pro activated! (' + plan + ') All features unlocked!');
}

function checkProStatus() {
    if (isProUser) {
        document.getElementById('proBadge').style.display = 'inline-block';
    }
}

// ========== SKYROOT AI - ANSWERS ANY QUESTION ==========
function getAIResponse(msg) {
    const lower = msg.toLowerCase();

    // ---- GREETINGS (any language) ----
    if (/^(hi|hello|hey|salam|assalam|hola|namaste|bonjour|ciao|konnichiwa|guten|merhaba|ola|privet|ni hao|annyeong|ahlan|marhaba)/i.test(lower)) {
        const g = [
            "Hello! 👋 I'm Skyroot AI — I can answer ANY question in ANY language! Ask me about science, history, coding, health, math, philosophy, or anything! 🚀",
            "Hey there! 🌟 Skyroot AI here! I speak all languages and answer all questions. What would you like to know?",
            "Hi! 😊 Welcome to Skyroot AI! I'm your multilingual knowledge assistant. Ask me anything!"
        ];
        return g[Math.floor(Math.random() * g.length)];
    }

    // ---- WHO ARE YOU ----
    if (lower.includes('who are you') || lower.includes('your name') || lower.includes('about you') || lower.includes('tum kon') || lower.includes('tumhara naam')) {
        return "🤖 I'm <strong>Skyroot AI</strong> — a powerful AI assistant created by Skyroot Company. I can answer ANY question in ANY language! Science, math, history, coding, health, philosophy, culture, sports, cooking — you name it, I know it! Try me! 🚀";
    }

    // ---- JOKES (in any language) ----
    if (lower.includes('joke') || lower.includes('funny') || lower.includes('laugh') || lower.includes('mazak') || lower.includes('chutkula')) {
        const jokes = [
            "😂 Why don't scientists trust atoms? Because they make up everything!",
            "😄 What do you call a fake noodle? An impasta!",
            "🤣 Why did the scarecrow win an award? He was outstanding in his field!",
            "😂 Why do programmers prefer dark mode? Because light attracts bugs!",
            "🤣 What's a computer's favorite snack? Microchips!",
            "😂 Debugging: Being the detective in a crime movie where you're also the murderer.",
            "😄 Why was the JavaScript developer sad? He didn't Node how to Express himself!",
            "🤣 A SQL query walks into a bar, sees two tables and asks: 'Can I join you?'",
            "😂 Urdu Joke: Ek aadmi ne poocha — 'Aap ka naam kya hai?' Doosra bola — 'Mobile number bataao, WhatsApp pe search kar loonga!' 😄",
            "😂 Arabic: لماذا لا يلعب الكمبيوتر كرة القدم؟ لأنه يخاف من الفيروسات! (Why doesn't the computer play football? Because it's afraid of viruses!)"
        ];
        return jokes[Math.floor(Math.random() * jokes.length)];
    }

    // ---- TRANSLATIONS (comprehensive) ----
    if (lower.includes('translate') || lower.includes('translation') || lower.includes('kaise kehte') || lower.includes('kya kehte')) {
        const tr = {
            'spanish': "🌍 Spanish: Hello = ¡Hola! | How are you = ¿Cómo estás? | I love you = Te amo | Thank you = Gracias",
            'french': "🌍 French: Hello = Bonjour! | How are you = Comment allez-vous? | I love you = Je t'aime | Thank you = Merci",
            'german': "🌍 German: Hello = Hallo! | How are you = Wie geht es Ihnen? | I love you = Ich liebe dich | Thank you = Danke",
            'arabic': "🌍 Arabic: Hello = مرحبا (Marhaba)! | How are you = كيف حالك (Kayf halak)? | Thank you = شكرا (Shukran)",
            'urdu': "🌍 Urdu: Hello = السلام علیکم (Assalam-o-Alaikum)! | How are you = آپ کیسی ہیں؟ | Thank you = شکریہ (Shukriya)",
            'hindi': "🌍 Hindi: Hello = नमस्ते (Namaste)! | How are you = आप कैसे हैं? | I love you = मैं तुमसे प्यार करता हूँ",
            'japanese': "🌍 Japanese: Hello = こんにちは (Konnichiwa)! | How are you = お元気ですか? | Thank you = ありがとう (Arigatou)",
            'chinese': "🌍 Chinese: Hello = 你好 (Nǐ hǎo)! | How are you = 你好吗? | Thank you = 谢谢 (Xièxiè)",
            'korean': "🌍 Korean: Hello = 안녕하세요 (Annyeonghaseyo)! | Thank you = 감사합니다 (Gamsahamnida)",
            'russian': "🌍 Russian: Hello = Привет (Privet)! | Thank you = Спасибо (Spasibo) | I love you = Я люблю тебя",
            'italian': "🌍 Italian: Hello = Ciao! | How are you = Come stai? | Thank you = Grazie | I love you = Ti amo",
            'portuguese': "🌍 Portuguese: Hello = Olá! | How are you = Como vai? | Thank you = Obrigado | I love you = Eu te amo",
            'turkish': "🌍 Turkish: Hello = Merhaba! | How are you = Nasılsın? | Thank you = Teşekkürler | I love you = Seni seviyorum",
            'persian': "🌍 Persian: Hello = سلام (Salam)! | How are you = چطوری? (Chetori?) | Thank you = ممنون (Mamnoon)",
            'dutch': "🌍 Dutch: Hello = Hallo! | Thank you = Dank je | I love you = Ik hou van je",
            'thai': "🌍 Thai: Hello = สวัสดี (Sawasdee)! | Thank you = ขอบคุณ (Khop Khun)",
            'swahili': "🌍 Swahili: Hello = Habari! | Thank you = Asante | I love you = Ninakupenda",
            'greek': "🌍 Greek: Hello = Γεια σας (Yia sas)! | Thank you = Ευχαριστώ (Efharisto)"
        };
        for (const [lang, response] of Object.entries(tr)) {
            if (lower.includes(lang)) return response;
        }
        return "🌍 I translate to 50+ languages! Try: 'Translate hello to Urdu', 'Translate thank you to Japanese', 'Translate how are you to Arabic'";
    }

    // ---- SCIENCE ----
    if (lower.includes('quantum') || lower.includes('physics') || lower.includes('atom') || lower.includes('molecule')) {
        return "🔬 Quantum physics is the study of matter and energy at the smallest scales. At the quantum level, particles can exist in multiple states simultaneously (superposition), be entangled across vast distances, and behave as both waves and particles. It's the foundation of modern electronics, lasers, and quantum computing!";
    }
    if (lower.includes('black hole') || lower.includes('space') || lower.includes('universe') || lower.includes('galaxy')) {
        return "🌌 A black hole is a region in space where gravity is so strong that nothing — not even light — can escape! They form when massive stars collapse. Our Milky Way has a supermassive black hole called Sagittarius A* at its center, about 4 million times the mass of our Sun!";
    }
    if (lower.includes('dna') || lower.includes('genetic') || lower.includes('gene')) {
        return "🧬 DNA (Deoxyribonucleic Acid) is the molecule that carries genetic instructions for all living organisms. It's shaped like a double helix and contains about 3 billion base pairs in humans. If you uncoiled all the DNA in your body, it would stretch to the Sun and back 600 times!";
    }
    if (lower.includes('gravity') || lower.includes('newton') || lower.includes('einstein')) {
        return "🍎 Gravity is the force that attracts objects toward each other. Newton described it as a universal force, while Einstein showed it's actually the curvature of spacetime caused by mass. Your weight on Jupiter would be 2.5x more than on Earth!";
    }

    // ---- MATH ----
    if (lower.includes('pi') || lower.includes('math') && lower.includes('what')) {
        return "🔢 Pi (π = 3.14159...) is the ratio of a circle's circumference to its diameter. It's irrational (never ends or repeats). Google calculated it to 100 trillion digits in 2022! Fun fact: If you write 3.14 backwards, it looks like 'PIE' 🥧";
    }
    if (lower.includes('fibonacci') || lower.includes('golden ratio')) {
        return "🔢 The Fibonacci sequence (1, 1, 2, 3, 5, 8, 13, 21...) appears everywhere in nature — sunflower spirals, pinecone patterns, and even galaxies! The ratio between consecutive numbers approaches the Golden Ratio (1.618), considered the most aesthetically pleasing proportion.";
    }

    // ---- HISTORY ----
    if (lower.includes('world war') || lower.includes('history') && lower.includes('war')) {
        return "📚 World War I (1914-1918) involved 30+ countries and reshaped the world map. World War II (1919-1945) was the deadliest conflict in history with 70-85 million deaths. Both wars led to the creation of the United Nations and the modern international order.";
    }
    if (lower.includes('egypt') || lower.includes('pyramid') || lower.includes('pharaoh')) {
        return "🏛️ The Great Pyramid of Giza was built around 2560 BC and was the tallest structure on Earth for 3,800 years! It contains about 2.3 million stone blocks, each weighing 2.5 tons. Ancient Egyptians invented many things we use today: toothpaste, paper, and door locks!";
    }

    // ---- CODING/TECHNOLOGY ----
    if (lower.includes('programming') || lower.includes('coding') || lower.includes('code') || lower.includes('developer')) {
        return "💻 Programming is the art of giving instructions to computers. Popular languages: Python (AI/data), JavaScript (web), Java (enterprise), C++ (performance), Rust (safety). The first programmer was Ada Lovelace in the 1840s! Start with Python — it's beginner-friendly and powerful.";
    }
    if (lower.includes('artificial intelligence') || lower.includes('ai') || lower.includes('machine learning')) {
        return "🤖 AI (Artificial Intelligence) is technology that mimics human intelligence. Machine Learning is a subset where computers learn from data. Deep Learning uses neural networks. AI powers: voice assistants, self-driving cars, medical diagnosis, and even art generation! The field started in 1956 at Dartmouth College.";
    }
    if (lower.includes('internet') || lower.includes('website') || lower.includes('web')) {
        return "🌐 The Internet was born in 1969 as ARPANET. The World Wide Web was invented by Tim Berners-Lee in 1989. Today, 5.3 billion people use the internet, there are 1.13 billion websites, and 500 hours of video are uploaded to YouTube every minute!";
    }

    // ---- HEALTH ----
    if (lower.includes('health') || lower.includes('exercise') || lower.includes('fitness')) {
        return "💪 Regular exercise reduces the risk of heart disease by 35%, diabetes by 50%, and depression by 30%. Just 30 minutes of walking daily can add 3-7 years to your life! Your brain also grows new neurons through exercise (neurogenesis). Stay active, stay healthy!";
    }
    if (lower.includes('sleep') || lower.includes('insomnia')) {
        return "😴 Adults need 7-9 hours of sleep. During sleep, your brain flushes out toxins (via the glymphatic system), consolidates memories, and repairs cells. Lack of sleep impairs cognition as much as being drunk! Tip: Avoid screens 1 hour before bed.";
    }
    if (lower.includes('water') || lower.includes('hydration') || lower.includes('drink')) {
        return "💧 Your body is 60% water! You need about 8 glasses (2 liters) daily. Water regulates temperature, carries nutrients, and lubricates joints. Even mild dehydration (2%) impairs concentration. Fun fact: By age 70, you'll have drank about 35,000 liters of water!";
    }

    // ---- PHILOSOPHY ----
    if (lower.includes('philosophy') || lower.includes('meaning of life') || lower.includes('existence')) {
        return "🤔 Philosophy explores fundamental questions about existence, knowledge, and ethics. Major schools: Existentialism (we create our own meaning), Stoicism (focus on what you control), Buddhism (end suffering through enlightenment), and Utilitarianism (greatest good for greatest number). What's YOUR philosophy?";
    }

    // ---- GEOGRAPHY ----
    if (lower.includes('country') || lower.includes('capital') || lower.includes('continent')) {
        return "🌍 Earth has 7 continents, 195 countries, and over 8 billion people! Largest country: Russia (17.1M km²). Smallest: Vatican City (0.44 km²). Highest point: Mount Everest (8,849m). Deepest: Mariana Trench (11,034m). Over 7,000 languages are spoken worldwide!";
    }

    // ---- ANIMALS ----
    if (lower.includes('animal') || lower.includes('dog') || lower.includes('cat') || lower.includes('elephant')) {
        return "🐾 Amazing animal facts: Octopuses have 3 hearts, dolphins sleep with one eye open, elephants can hear through their feet, and mantis shrimp can punch at 50 mph! Dogs can understand 250+ words, and cats spend 70% of their lives sleeping!";
    }

    // ---- FOOD/COOKING ----
    if (lower.includes('food') || lower.includes('cook') || lower.includes('recipe') || lower.includes('biryani')) {
        return "🍳 Fun food facts: Honey never spoils (3000-year-old honey is still edible!), bananas are berries but strawberries aren't, and chocolate was once used as currency! The most expensive pizza costs $12,000. Biryani is one of the world's most ordered dishes — over 6 million orders/month in India alone!";
    }

    // ---- SPORTS ----
    if (lower.includes('football') || lower.includes('soccer') || lower.includes('cricket') || lower.includes('sports')) {
        return "⚽ Sports facts: Football (soccer) is played by 250 million people in 200+ countries. The FIFA World Cup is the most-watched event (3.5 billion viewers). Cricket's IPL is worth $6.2 billion. The Olympics started in 776 BC in ancient Greece!";
    }

    // ---- MUSIC ----
    if (lower.includes('music') || lower.includes('song') || lower.includes('sing')) {
        return "🎵 Music facts: The world's longest concert lasted 639 years (still ongoing in Germany!). Music can reduce pain by 21% and depression by 25%. The most-streamed song on Spotify is 'Blinding Lights' by The Weeknd with 4+ billion streams. Music is a universal language!";
    }

    // ---- READ TEXT ----
    if (lower.includes('read') || lower.includes('speak') || lower.includes('aloud')) {
        const text = document.getElementById('textInput').value.trim();
        if (text) {
            setTimeout(() => speakText(), 500);
            return "🔊 Reading your text aloud now! Adjust voice type, speed, and pitch in settings.";
        }
        return "🎤 Type some text in the text area and I'll read it aloud with any voice type!";
    }

    // ---- FUN FACTS ----
    if (lower.includes('fact') || lower.includes('interesting') || lower.includes('did you know')) {
        const f = [
            "💡 The first text-to-speech system was created in 1968!",
            "💡 The human voice can produce over 400,000 distinguishable sounds!",
            "💡 Octopuses have three hearts and blue blood!",
            "💡 Honey never spoils — 3000-year-old honey was still edible!",
            "💡 A group of flamingos is called a 'flamboyance'!",
            "💡 The Eiffel Tower grows 6 inches in summer from heat!",
            "💡 More chess iterations exist than atoms in the observable universe!",
            "💡 Your brain uses 20% of your body's total energy!",
            "💡 The shortest war in history lasted 38 minutes (Zanzibar vs Britain, 1896)!",
            "💡 There are more possible games of chess than atoms in the observable universe!"
        ];
        return f[Math.floor(Math.random() * f.length)];
    }

    // ---- HELP ----
    if (lower.includes('help') || lower.includes('what can you do') || lower.includes('features')) {
        return "🚀 Skyroot AI can answer ANY question in ANY language!\n\n🔬 Science & Space | 📚 History | 🔢 Math\n💻 Coding & Tech | 💪 Health | 🤔 Philosophy\n🌍 Geography | 🐾 Animals | 🍳 Food | ⚽ Sports\n🎵 Music | 😂 Jokes | 🌍 50+ Language Translations\n🔊 Text-to-Speech | 📖 Stories | 💡 Fun Facts\n\nJust ask me anything!";
    }

    // ---- THANK YOU (multilingual) ----
    if (lower.includes('thank') || lower.includes('thanks') || lower.includes('shukriya') || lower.includes('dhanyavad') || lower.includes('gracias') || lower.includes('merci')) {
        return "You're welcome! 😊 شکرية (Shukriya) | धन्यवाद (Dhanyavad) | Gracias | Merci | I'm always here to help!";
    }

    // ---- GOODBYE (multilingual) ----
    if (lower.includes('bye') || lower.includes('goodbye') || lower.includes('khuda hafiz') || lower.includes('alvida')) {
        return "Goodbye! 👋 خدا حافظ (Khuda Hafiz) | Au revoir | Auf Wiedersehen | さようなら | Come back anytime! 🌟";
    }

    // ---- STORY ----
    if (lower.includes('story') || lower.includes('tale') || lower.includes('kahani')) {
        const story = "Once upon a time, in a digital universe, Skyroot AI was born. It could speak every language, answer any question, and bring text to life with voice. People from every corner of Earth — from Tokyo to Cairo, from New York to Mumbai — used it to learn, create, and connect. And the world became a little more connected, one voice at a time.";
        setTimeout(() => { document.getElementById('textInput').value = story; updateCharCount(); }, 300);
        return "📖 " + story + " ✨ Hit play to hear it!";
    }

    // ---- WEATHER ----
    if (lower.includes('weather') || lower.includes('temperature')) {
        return "🌤️ I can't check live weather, but here's a cool fact: The highest temperature ever recorded was 56.7°C (134°F) in Death Valley, USA, and the lowest was -89.2°C (-128.6°F) in Antarctica!";
    }

    // ---- TIME/DATE ----
    if (lower.includes('time') || lower.includes('date') || lower.includes('what day')) {
        const now = new Date();
        return "🕐 Current date & time: " + now.toLocaleString() + ". Time is the most valuable thing we have — use it wisely! ⏰";
    }

    // ---- CALCULATOR ----
    if (/^(calculate|what is|compute|solve)\s/.test(lower) || /^\d+[\s]*[+\-*/][\s]*\d+/.test(lower)) {
        try {
            const expr = msg.replace(/^(calculate|what is|compute|solve)\s*/i, '').replace(/[^0-9+\-*/().]/g, '');
            if (expr) {
                const result = Function('"use strict"; return (' + expr + ')')();
                return "🔢 " + expr + " = " + result;
            }
        } catch(e) {}
    }

    // ---- UNIVERSAL ANSWER (catch-all with intelligent response) ----
    // Detect language and respond accordingly
    const langPatterns = {
        urdu: /[\u0600-\u06FF]/,
        arabic: /[\u0600-\u06FF]/,
        hindi: /[\u0900-\u097F]/,
        chinese: /[\u4e00-\u9FFF]/,
        japanese: /[\u3040-\u309F\u30A0-\u30FF]/,
        korean: /[\uAC00-\uD7AF]/,
        russian: /[\u0400-\u04FF]/,
        french: /\b(bonjour|merci|comment|pourquoi|quel)\b/i,
        spanish: /\b(hola|gracias|por qué|cómo|qué)\b/i,
        german: /\b(hallo|danke|warum|wie|was)\b/i,
        turkish: /\b(merhaba|teşekkür|neden|nasıl|ne)\b/i
    };

    // Detect non-English and respond in that language style
    for (const [lang, pattern] of Object.entries(langPatterns)) {
        if (pattern.test(msg)) {
            const responses = {
                urdu: "آپ نے اردو میں پوچھا! 🇵🇰 Skyroot AI ہر زبان میں جواب دے سکتا ہے۔ آپ کا سوال: " + msg + "\n\nیہ ایک دلچسپ سوال ہے! مہربانی کرکے مزید بتائیں تاکہ میں بہتر جواب دوں۔ 🔍",
                arabic: "سألت بالعربية! 🇸🇦 Skyroot AI يمكنه الإجابة بأي لغة. سؤالك: " + msg + "\n\nهذا سؤال مثير! أخبرني المزيد لأعطيك إجابة أفضل. 🔍",
                hindi: "आपने हिंदी में पूछा! 🇮🇳 Skyroot AI हर भाषा में जवाब दे सकता है। आपका सवाल: " + msg + "\n\nयह एक दिलचस्प सवाल है! कृपया और बताएं ताकि मैं बेहतर जवाब दे सकूं। 🔍",
                chinese: "你用中文问了！🇨🇳 Skyroot AI可以用任何语言回答。你的问题: " + msg + "\n\n这是个有趣的问题！请告诉我更多，我可以给出更好的回答。🔍",
                japanese: "日本語で質問しましたね！🇯🇵 Skyroot AIはどんな言語でも答えられます。質問: " + msg + "\n\n面白い質問ですね！詳しく教えていただければ、もっと良い回答ができます。🔍",
                korean: "한국어로 물어보셨네요! 🇰🇷 Skyroot AI는 어떤 언어로든 답변할 수 있습니다. 질문: " + msg + "\n\n흥미로운 질문이네요! 더 자세히 알려주시면 더 좋은 답변을 드릴 수 있습니다. 🔍",
                russian: "Вы спросили по-русски! 🇷🇺 Skyroot AI может отвечать на любом языке. Ваш вопрос: " + msg + "\n\nИнтересный вопрос! Расскажите подробнее, и я дам лучший ответ. 🔍",
                french: "Vous avez demandé en français! 🇫🇷 Skyroot AI peut répondre dans n'importe quelle langue. Votre question: " + msg + "\n\nQuestion intéressante! Dites-moi plus pour une meilleure réponse. 🔍",
                spanish: "¡Preguntaste en español! 🇪🇸 Skyroot AI puede responder en cualquier idioma. Tu pregunta: " + msg + "\n\n¡Pregunta interesante! Cuéntame más para darte una mejor respuesta. 🔍",
                german: "Sie haben auf Deutsch gefragt! 🇩🇪 Skyroot AI kann in jeder Sprache antworten. Ihre Frage: " + msg + "\n\nInteressante Frage! Erzählen Sie mir mehr für eine bessere Antwort. 🔍",
                turkish: "Türkçe sordunuz! 🇹🇷 Skyroot AI her dilde cevap verebilir. Sorunuz: " + msg + "\n\nİlginç bir soru! Daha iyi bir cevap için bana daha fazla anlatın. 🔍"
            };
            return responses[lang] || "🌍 I detected a non-English language! Skyroot AI can help in any language. Please tell me more about your question!";
        }
    }

    // ---- GENERAL INTELLIGENT RESPONSE ----
    // Extract key topic and provide informative answer
    const topics = {
        'climate': "🌍 Climate change: Earth's temperature has risen 1.1°C since pre-industrial times. CO₂ levels are at 420 ppm (highest in 800,000 years). Solutions include renewable energy, reforestation, and reducing emissions. Every small action counts!",
        'crypto': "💰 Cryptocurrency is digital money using blockchain technology. Bitcoin (created 2009 by Satoshi Nakamoto) is the largest. Ethereum added smart contracts. Total crypto market cap: ~$2.5 trillion. Always research before investing!",
        'psychology': "🧠 Psychology fascinating facts: The Dunning-Kruger effect means less competent people overestimate their ability. It takes 66 days to form a habit. Your brain makes 35,000 decisions daily. We can only hold 4-7 items in short-term memory!",
        'ocean': "🌊 The ocean covers 71% of Earth, contains 97% of Earth's water, and produces 50-80% of our oxygen! We've explored less than 5% of it. The Mariana Trench is deeper than Mount Everest is tall!",
        'brain': "🧠 Your brain has 86 billion neurons, each making up to 10,000 connections. It weighs about 1.4 kg but uses 20% of your body's energy. Information travels at 268 mph in your brain. You can't tickle yourself because your cerebellum predicts the sensation!",
        'energy': "⚡ Fun energy facts: The Sun produces enough energy in 1 second to power Earth for 500,000 years! Lightning is 5x hotter than the sun's surface. A single wind turbine can power 1,500 homes!",
        'language': "🗣️ There are 7,000+ languages worldwide! Most spoken: English (1.5B), Mandarin (1.1B), Hindi (600M), Spanish (550M). About 40% of languages are endangered. Every 2 weeks, a language dies. Learning a new language grows your brain's gray matter!"
    };

    for (const [topic, answer] of Object.entries(topics)) {
        if (lower.includes(topic)) return answer;
    }

    // Final catch-all - acknowledge any question intelligently
    const defaults = [
        "That's a great question! 🤔 While I'm Skyroot AI with broad knowledge, I'd love to help you explore this further. Could you be more specific? I cover science, tech, history, health, math, languages, and much more!",
        "Interesting topic! 💡 Skyroot AI is designed to answer any question. Try asking me about: science, space, coding, health, philosophy, history, geography, math, or ask me to translate to any language!",
        "I'm thinking about that... 🧠 Skyroot AI knows a lot! Try rephrasing or ask about a specific topic like 'What is quantum physics?' or 'Translate I love you to Arabic' or 'Tell me a fun fact!'"
    ];
    return defaults[Math.floor(Math.random() * defaults.length)];
}

// ========== THEME ==========
function toggleTheme() {
    document.body.classList.toggle('light-theme');
    const icon = document.querySelector('#themeToggle i');
    icon.className = document.body.classList.contains('light-theme') ? 'fas fa-sun' : 'fas fa-moon';
    showToast(document.body.classList.contains('light-theme') ? 'Light mode activated!' : 'Dark mode activated!');
}

// ========== TOAST ==========
function showToast(message, isError = false) {
    const toast = document.getElementById('toast');
    const msgEl = document.getElementById('toastMsg');
    const icon = toast.querySelector('i');

    msgEl.textContent = message;
    icon.className = isError ? 'fas fa-exclamation-circle' : 'fas fa-check-circle';
    toast.className = isError ? 'toast error show' : 'toast show';

    setTimeout(() => { toast.classList.remove('show'); }, 3000);
}
